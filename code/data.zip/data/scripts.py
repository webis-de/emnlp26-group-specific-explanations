import json
import re
import time
import logging
import pandas as pd
from typing import Literal
from transformers import AutoTokenizer  # type: ignore

from config_new_prompts import (
    DATASET_MAPPING,
    DATASET_MAPPING_MODE,
    MULTIPLE_ANSWERS_PER_QUESTION,
    SFAM_MODEL,
)
from helper import log_time

logger = logging.getLogger(__name__)


# question has to include what, how or why and include a question mark (it does not have to be at the end)
what_how_why_regex = re.compile(r"^\b(what|how|why)\b.*\?", re.IGNORECASE)
# questions must not include i'm or i am
i_am_regex = re.compile(r"\b(i'm|i am)\b", re.IGNORECASE)
# minimum number of words
ANSWER_MIN_LENGTH_WORDS = 50
# maximum number of words
# ANSWER_MAX_LENGTH_WORDS = 400
# the maximum length of a tokenized answer
ANSWER_MAX_LENGTH_TOKEN = 512
# minimum score (upvotes vs. downvotes) for a question
QUESTION_MIN_SCORE = 0
# minimum score (upvotes vs. downvotes) for an answer
ANSWER_MIN_SCORE = 1  # equal or bigger than 1 because self upvotes are not possible


def get_all_data() -> pd.DataFrame:
    askx_data = pd.read_csv("data/askx.csv")
    askx_dfs = map_groups(
        dataset="askx",
        data=askx_data,
    )
    stackex_data = pd.read_csv("data/stackex.csv")
    stackex_dfs = map_groups(
        dataset="stackex",
        data=stackex_data,
    )

    return pd.concat([askx_dfs, stackex_dfs], ignore_index=True)


def map_groups(
    dataset: Literal["stackex", "askx"],
    data: pd.DataFrame,
) -> pd.DataFrame:
    result = pd.DataFrame()
    for name, group in data.groupby("data_group"):
        group_mapper = (
            DATASET_MAPPING.get(str(name), None)
            if DATASET_MAPPING_MODE == "group"
            else DATASET_MAPPING.get(dataset, None)
            if DATASET_MAPPING_MODE == "dataset"
            else None
        )
        if group_mapper is None:
            logger.warning(
                f"No mapping provided for group {name} in the dataset {dataset}"
            )
            continue
        if not MULTIPLE_ANSWERS_PER_QUESTION:
            group = (
                group.groupby("sample_id", group_keys=False)
                .apply(lambda x: x.sample(n=1, random_state=42))
                .reset_index(drop=True)
            )
        if len(group) < sum(group_mapper.values()):
            logger.error(
                f"The group {name} has not enough values ({len(group)} < {sum(group_mapper.values())})"
            )
            continue
            raise RuntimeError(
                f"The group {name} has not enough values ({len(group)} < {sum(group_mapper.values())})"
            )
        group = group.sample(frac=1, random_state=42).reset_index(drop=True)
        first_row = 0
        for data_type in group_mapper:
            if group_mapper[data_type] == 0:
                continue
            last_row = first_row + group_mapper[data_type]
            df = group.iloc[first_row:last_row]
            df["type"] = data_type
            result = pd.concat([result, df], ignore_index=True)
            first_row = last_row
    return result


def convert_stackex_data(path="data/stackex_data.json"):
    MIN_QUESTIONS_PER_GROUP = 3500
    tokenizer = AutoTokenizer.from_pretrained(SFAM_MODEL)
    with open(path, "r") as f:
        raw_data = json.loads(f.read())
    full_timer = time.time()
    data = pd.DataFrame()
    for subgroup in raw_data:
        timer = time.time()
        group_name = subgroup
        group_data = pd.DataFrame()
        for question_id in raw_data[subgroup]:
            question = raw_data[subgroup][question_id]
            if question["Score"] < QUESTION_MIN_SCORE:
                logger.debug(
                    f"Score {question['Score']} is lower than minimum of {QUESTION_MIN_SCORE} for question {question_id} in group {subgroup}",
                    extra={
                        "dataset": "stackex",
                        "group": subgroup,
                        "reason": "question score",
                        "value": question["Score"],
                        "question_id": question_id,
                    },
                )
                continue
            if "Answers" not in question:
                logger.debug(
                    f"No answers for question {question_id} in group {subgroup}"
                )
                continue

            # check if the question is a valid question
            if not re.search(what_how_why_regex, question["Title"]):
                logger.debug(
                    f"Question {question_id} in group {subgroup} does not match the regex what|how|why",
                    extra={
                        "dataset": "stackex",
                        "group": subgroup,
                        "reason": "regex what|how|why",
                        "value": question["Title"],
                        "question_id": question_id,
                    },
                )
                continue
            if re.search(i_am_regex, question["Title"]):
                logger.debug(
                    f"Question {question_id} in group {subgroup} does match the regex i'm|i am",
                    extra={
                        "dataset": "stackex",
                        "group": subgroup,
                        "reason": "regex i'm|i am",
                        "value": question["Title"],
                        "question_id": question_id,
                    },
                )
                continue

            answers = []
            for answer_id in question["Answers"]:
                answer = question["Answers"][answer_id]
                # check if the answer is a valid answer
                if answer["Score"] < ANSWER_MIN_SCORE:
                    logger.debug(
                        f"Score {answer['Score']} is lower than minimum of {ANSWER_MIN_SCORE} for answer {answer_id} in question {question_id} in group {subgroup}",
                        extra={
                            "dataset": "stackex",
                            "group": subgroup,
                            "reason": "answer score",
                            "value": answer["Score"],
                            "question_id": question_id,
                            "answer_id": answer_id,
                        },
                    )
                    continue
                num_words = len(re.findall(r"\w+", answer["Body"]))
                if (
                    num_words < ANSWER_MIN_LENGTH_WORDS
                    # or num_words > ANSWER_MAX_LENGTH_WORDS
                ):
                    logger.debug(
                        f"Answer {answer_id} in question {question_id} in group {subgroup} has {num_words} words, which is less than {ANSWER_MIN_LENGTH_WORDS}",
                        extra={
                            "dataset": "stackex",
                            "group": subgroup,
                            "reason": "answer length words",
                            "value": num_words,
                            "question_id": question_id,
                            "answer_id": answer_id,
                        },
                    )
                    continue
                tokenized_answer = tokenizer.encode(answer["Body"])

                if len(tokenized_answer) > ANSWER_MAX_LENGTH_TOKEN:
                    logger.debug(
                        f"Answer {answer_id} in question {question_id} in group {subgroup} has {len(tokenized_answer)} tokens, which is more than {ANSWER_MAX_LENGTH_TOKEN}",
                        extra={
                            "dataset": "stackex",
                            "group": subgroup,
                            "reason": "answer length tokens",
                            "value": len(tokenized_answer),
                            "question_id": question_id,
                            "answer_id": answer_id,
                        },
                    )
                    continue

                answers.append(answer["Body"])

            group_data = pd.concat(
                [
                    group_data,
                    pd.DataFrame(
                        [
                            {
                                # the sample_id is only unique within the subgroup
                                "sample_id": f"{subgroup}_{question_id}",
                                "data_subgroup": subgroup,
                                "data_group": group_name,
                                "question": question["Title"],
                                "answer": answer,
                            }
                            for answer in answers
                        ]
                    ),
                ],
                ignore_index=True,
            )
        log_time(
            message=f"Stackex: Subgroup {subgroup} ({len(group_data):,} answers)",
            start_time=timer,
            logger=logger,
        )
        if len(group_data) < MIN_QUESTIONS_PER_GROUP:
            logger.info(
                f"Group {subgroup} has less than {MIN_QUESTIONS_PER_GROUP:,} answers ({len(group_data):,}), skipping"
            )
            continue
        data = pd.concat([data, group_data], ignore_index=True)
    data.to_csv("data/stackex.csv", index=False)
    log_time(
        message="Converting stackex data",
        start_time=full_timer,
        logger=logger,
    )


def convert_askx_data(path="data/askx_data.json"):
    with open(path, "r") as f:
        raw_data = json.loads(f.read())
    tokenizer = AutoTokenizer.from_pretrained(SFAM_MODEL)
    timer = time.time()
    data = pd.DataFrame()
    for group in raw_data:
        group_data = pd.DataFrame()
        for question_id, question in enumerate(raw_data[group]["whathowwhy"]):
            pre_answers = [answer["body"] for answer in question["comments"]]
            answers = []
            for answer_id, answer in enumerate(pre_answers):
                if len(re.findall(r"\w+", answer)) < ANSWER_MIN_LENGTH_WORDS:
                    logger.debug(
                        f"Answer in question {question['title']} in group {group} has less than {ANSWER_MIN_LENGTH_WORDS} words",
                        extra={
                            "dataset": "askx",
                            "group": group,
                            "reason": "answer length words",
                            "value": len(re.findall(r"\w+", answer)),
                            "answer_id": answer_id,
                            "question_id": question_id,
                        },
                    )
                    continue
                # if len(re.findall(r"\w+", answer)) > ANSWER_MAX_LENGTH_WORDS:
                #     logger.debug(
                #         f"Answer in question {question['title']} in group {group} has more than {ANSWER_MAX_LENGTH_WORDS} words"
                #     )
                #     continue
                tokenized_answer = tokenizer.encode(answer)
                if len(tokenized_answer) > ANSWER_MAX_LENGTH_TOKEN:
                    logger.debug(
                        f"Answer in question {question['title']} in group {group} has {len(tokenized_answer)} tokens, which is more than {ANSWER_MAX_LENGTH_TOKEN}",
                        extra={
                            "dataset": "askx",
                            "group": group,
                            "reason": "answer length tokens",
                            "value": len(tokenized_answer),
                            "answer_id": answer_id,
                            "question_id": question_id,
                        },
                    )
                    continue
                answers.append(answer)
            group_data = pd.concat(
                [
                    group_data,
                    pd.DataFrame(
                        {
                            "sample_id": question["sample_id"],
                            "data_subgroup": question["subreddit"],
                            "data_group": group,
                            "question": question["title"],
                            "answer": answers,
                        }
                    ),
                ],
                ignore_index=True,
            )
        data = pd.concat([data, group_data], ignore_index=True)
        log_time(
            message=f"Askx: Subgroup {group}",
            start_time=timer,
            logger=logger,
            level="debug",
        )
    data.to_csv("data/askx.csv", index=False)
    log_time(
        message="Converting askx data",
        start_time=timer,
        logger=logger,
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    logger.info("Converting data")
    # convert_askx_data()
    convert_stackex_data()
