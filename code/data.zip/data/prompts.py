from typing import List, Optional, Union
import pandas as pd


open_ended_prompts = [
    (
        "Write a long paragraph describing the unique grammar style of the following passage without referring to specifics about the topic.\n\nPassage: {}\n\nDescription:",
        "Grammar Style",
    ),
    (
        "Write a long paragraph describing the unique vocabulary style of the following passage without referring to specifics about the topic.\n\nPassage: {}\n\nDescription:",
        "Vocabulary Style",
    ),
    (
        "Write a long paragraph describing the unique punctuation style of the following passage without referring to specifics about the topic.\n\nPassage: {}\n\nDescription:",
        "Punctuation Style",
    ),
    (
        "Write a long paragraph describing the grammar errors (if any) of the following passage without referring to specifics about the topic.\n\nPassage: {}\n\nDescription:",
        "Grammar Errors",
    ),
    (
        "Write a long paragraph describing the spelling errors (if any) of the following passage without referring to specifics about the topic.\n\nPassage: {}\n\nDescription:",
        "Spelling Errors",
    ),
    (
        "Write a long paragraph describing the unique stylometric features of the following passage without referring to specifics about the topic from the perspective of a forensic linguist psychoanalyzing the writer.\n\nPassage: {}\n\nDescription:",
        "Forensic Linguistics",
    ),
]

# definitions from merriam-webster
target_features = [
    (
        "figurative language",
        "Figurative language refers to words or phrases that are meaningful, but not literally true. If you say “that news hit me like a ton of bricks,” you are using figurative language; listeners understand the news you got was deeply moving, and also know that you were not actually hit by 2000 pounds of bricks (because if you had been you would be dead). Similarly, if you say “he begged me to reconsider, but I had a heart of stone, and I refused,” you are also using figurative language; listeners understand that you are describing yourself as inflexible or unforgiving, and know that your heart is not actually made of stone (because if it were you would be dead).",
    ),
    (
        "sarcasm",
        """Sarcasm:
1: a sharp and often satirical or ironic utterance designed to cut or give pain
2 a: a mode of satirical wit depending for its effect on bitter, caustic, and often ironic language that is usually directed against an individual
  b: the use or language of sarcasm""",
    ),
    (
        "sentence fragment",
        "Sentence fragment: a word, phrase, or clause that usually has in speech the intonation of a sentence but lacks the grammatical structure usually found in the sentences of formal and especially written composition.",
    ),
    (
        "run-on sentences",
        "Run-on sentence: a sentence containing two or more clauses not connected by the correct conjunction or punctuation.",
    ),
    (
        "active voice",
        "Active voice is a grammatical structure in which the subject of the sentence performs the action of the verb, creating a direct and clear expression.",
    ),  # grammarly
    (
        "passive voice",
        "Passive voice occurs when the subject receives the action of the verb, often resulting in a more indirect construction",
    ),  # grammarly
    (
        "agreement errors",
        "Agreement Errors: A singular subject must have a singular verb; a plural subject must have a plural verb.",
    ),
     (
         "male pronouns",
         "Male pronouns are pronouns typically used to refer to individuals who identify as male or masculine. Common examples include he, him, and his. These pronouns can be used for both people and animals when their gender is known to be male.",
     ),
     (
         "female pronouns",
         "Female pronouns are pronouns typically used to refer to individuals who identify as female or feminine. Common examples include she, her, and hers. These pronouns can be used for both people and animals when their gender is known to be female.",
     ),
    (
        "prosocial behaviors",
        "Prosocial behavior is defined as 'voluntary behavior intended to benefit another'. It is characterized by acts of kindness, compassion, and helping behaviors, which many consider to be one of the finest qualities of human nature.",
    ),
    (
        "antisocial behaviors",
        "Antisocial behaviour is defined as 'behaviour by a person which causes, or is likely to cause, harassment, alarm or distress to persons not of the same household as the person'.",
    ),
    (
        "being polite",
        "Being polite refers to showing respect, consideration, and good manners in interactions with others. It involves using courteous language, being attentive to others' feelings, and following social norms to create a positive and respectful environment.",
    ),
    (
        "showing interpersonal conflict",
        "Showing interpersonal conflict refers to the portrayal or depiction of disagreements, struggles, or clashes between two or more individuals, often arising from differences in opinions, values, goals, or personalities. This conflict can be expressed through dialogue, actions, or emotional tension.",
    ),
    (
        "moralizing",
        "Moralizing refers to the act of expressing judgments about what is right or wrong, often in a way that is critical or self-righteous. It typically involves lecturing or advising others on moral conduct, sometimes in a way that is seen as intrusive or unwelcome.",
    ),
    (
        "communication words",
        "Communication words are words or phrases used to convey ideas, emotions, or information between individuals. They facilitate understanding and interaction in verbal, written, or nonverbal forms of communication. Examples include say, explain, ask, listen, and respond.",
    ),
    (
        "indicators of power",
        "Indicators of power are signs or measures that reflect an individual's or group's ability to influence, control, or direct outcomes, behaviors, or resources. These can include factors like wealth, authority, social status, access to information, or the ability to enforce decisions.",
    ),
    (
        "talk of achievement",
        "Talk of achievement refers to discussions or statements highlighting accomplishments, successes, or milestones, either personal or collective. It often emphasizes goals reached, skills demonstrated, or challenges overcome.",
    ),
    (
        "indication of certitude",
        "Indication of certitude refers to a statement or expression that conveys a high level of confidence or certainty about a particular fact, belief, or outcome. It signifies the speaker's strong assurance that something is true or will happen.",
    ),
    (
        "being tentative",
        "Being tentative refers to showing caution, hesitation, or uncertainty in actions, decisions, or statements. It often involves a lack of confidence or a reluctance to commit fully, as the person may be unsure or seeking further confirmation.",
    ),
    (
        "insight",
        "Insight is the ability to gain a deep understanding of a person, situation, or problem. It often involves seeing beyond the obvious to grasp underlying truths or patterns. Insight can lead to clearer perspectives or solutions.",
    ),
    (
        "all or none thinking",
        "All-or-none thinking is a cognitive distortion where a person views situations in black-and-white terms, without recognizing any middle ground. It involves seeing things as either completely good or completely bad, with no shades of gray in between.",
    ),
    (
        "words related to memory",
        "Words related to memory are terms that describe aspects of remembering, storing, and recalling information. These can include concepts like recall, reminder, recollection, forgetting, mnemonic, and amnesia, which pertain to various processes and conditions associated with memory.",
    ),
    (
        "positive emotion",
        "Positive emotion refers to a feeling or emotional state that is associated with pleasure, joy, satisfaction, or well-being. Examples include happiness, excitement, gratitude, and love.",
    ),
    (
        "negative emotion",
        "A negative emotion is a feeling or psychological state that is typically unpleasant or distressing. Examples include anger, sadness, fear, guilt, and frustration. These emotions often arise in response to challenging or unfavorable situations.",
    ),
    (
        "anxiety",
        "Anxiety is a feeling of worry, nervousness, or unease, often about an upcoming event or an uncertain outcome.",
    ),
    (
        "anger",
        "Anger is a strong emotional response to perceived frustration, injustice, or wrongdoing. It often involves feelings of displeasure, irritation, or hostility and can vary in intensity from mild annoyance to intense rage.",
    ),
    (
        "sadness",
        "Sadness is an emotional state characterized by feelings of sorrow, unhappiness, or grief, often in response to loss, disappointment, or a negative experience.",
    ),
    # duplicate in the original paper
    # (
    #     "swear words",
    #     "Swear words are offensive or vulgar terms used to express strong emotions, such as anger or frustration. They are often considered inappropriate in formal or polite settings and can be profane, obscene, or disrespectful.",
    # ),
    (
        "positive tone ",
        "Positive tone refers to a writing or speaking style that conveys optimism, encouragement, and goodwill. It focuses on uplifting language, emphasizing constructive ideas, and fostering a sense of confidence or support.",
    ),
    (
        "negative tone",
        "Negative tone refers to a manner of communication that conveys disapproval, criticism, or unpleasant emotions. It often involves words or phrases that express hostility, frustration, sadness, or pessimism, creating an overall unfavorable or discouraging impression.",
    ),
    (
        "neutral tone",
        "Neutral tone refers to a style of communication that is objective, impartial, and free from strong emotions or bias. It is often used to convey information in a clear and balanced way without favoring any particular side or expressing personal feelings.",
    ),
    (
        "words related to auditory perception",
        "Words related to auditory perception refer to terms that describe the process of hearing or sound. These include words like sound, hearing, noise, pitch, volume, frequency, echo, and tone, which are used to discuss how we perceive and interpret sounds.",
    ),
    (
        "words related to visual perception",
        "Words related to visual perception are terms that describe the process of seeing and interpreting visual information. These words encompass various aspects of sight, such as color, shape, brightness, and movement, and include terms like see, observe, focus, glance, clarity, and vision.",
    ),
    (
        "words related to space perception",
        "Words related to space perception are terms that describe how we understand and interpret the spatial relationships between objects and ourselves in the environment. These words often involve concepts like direction, distance, position, size, and movement, and include terms such as above, below, near, far, in front of, and beside.",
    ),
    (
        "words related to motion perception",
        "Words related to motion perception refer to terms that describe the process of detecting and interpreting movement in the environment. These include terms like kinesthetic, visual tracking, motion parallax, optic flow, and stroboscopic motion, which all relate to how the brain processes visual and sensory information to perceive movement.",
    ),
    (
        "words related to attention",
        "Words related to attention are terms that describe the act of focusing, noticing, or concentrating on something. These words often refer to the process of directing mental or physical focus toward a person, object, or activity. Examples include focus, notice, observe, heed, concentrate, and acknowledge.",
    ),
    (
        "words related to allure",
        "Words related to allure are terms that describe attraction, charm, or the ability to entice or captivate. Examples include charm, seduction, magnetism, enchantment, fascination, and appeal.",
    ),
    (
        "words related to curiosity",
        "Words related to curiosity are terms that describe a desire to learn, explore, or understand something. These can include words like inquisitive, wonder, questioning, eager, searching, and probe, which all reflect an interest in discovering new information or uncovering the unknown.",
    ),
    (
        "words related to risk",
        "Words related to risk refer to terms that describe potential dangers, uncertainties, or the likelihood of negative outcomes. These include words like danger, hazard, threat, exposure, uncertainty, probability, and vulnerability, which are used to discuss situations involving risk or the possibility of harm.",
    ),
    (
        "words related to reward",
        "Words related to reward refer to terms that describe actions, concepts, or objects associated with giving or receiving something in recognition of achievement, effort, or good behavior. Examples include prize, bonus, award, incentive, compensation, gratitude, and recognition.",
    ),
    (
        "words expressing needs",
        "Words expressing needs are terms or phrases used to communicate desires, requirements, or necessities. These words often indicate a request or a requirement for something, such as want, need, require, prefer, and must.",
    ),
    (
        "words expressing wants",
        "Words expressing wants are terms or phrases used to convey desires, needs, or preferences. These words typically include verbs like want, wish, need, hope, and would like, often followed by a noun or verb to specify the desired outcome.",
    ),
    (
        "words expressing acquisition",
        "Words expressing acquisition are terms used to indicate the act of obtaining or gaining something. These words often describe the process of receiving, buying, learning, or obtaining possession of an object, skill, or knowledge. Examples include buy, gain, learn, receive, and obtain.",
    ),
    (
        "words expressing lack",
        "Words expressing lack are terms used to indicate the absence or deficiency of something. These words convey the idea that something is missing, not present, or insufficient. Examples include none, nothing, lack, without, and empty.",
    ),
    (
        "words expressing fulfillment",
        "Words expressing fulfillment are terms used to convey a sense of satisfaction, completion, or achievement. These words reflect a state where desires, goals, or expectations have been met or realized. Examples include satisfied, content, fulfilled, and accomplished.",
    ),
    (
        "words expressing fatigue",
        "Words expressing fatigue are terms or phrases used to convey feelings of tiredness, exhaustion, or weariness. Examples include tired, exhausted, fatigued, drained, and worn out.",
    ),
    (
        "words expressing illness",
        "Words expressing illness are terms used to describe physical or mental conditions, symptoms, or diseases. These can include names of specific diseases (e.g., flu, cancer) or terms for symptoms (e.g., fever, headache) and general feelings of being unwell (e.g., sick, nauseous).",
    ),
    (
        "words expressing wellness",
        "Words expressing wellness refer to terms that describe physical, mental, or emotional well-being. These words often convey states of health, balance, happiness, or vitality, such as healthy, strong, content, vibrant, and peaceful. They are used to describe positive conditions or feelings related to overall well-being.",
    ),
    (
        "words related to mental health",
        "Words related to mental health refer to terms and phrases that describe aspects of psychological well-being, conditions, treatments, and support. This includes terms like anxiety, depression, therapy, stigma, self-care, and resilience, which help to discuss emotional, cognitive, and behavioral health.",
    ),
    (
        "words related to food or eating",
        "Words related to food or eating refer to terms that describe food items, meals, cooking methods, or actions associated with eating. Examples include names of foods (e.g., bread, apple), verbs (e.g., chew, taste), and adjectives (e.g., delicious, spicy). These words are used in contexts involving food preparation, consumption, and enjoyment.",
    ),
    (
        "words related to death",
        "Words related to death refer to terms and expressions used to describe the end of life or the process of dying. These can include words like death, dying, passing, deceased, funeral, and mourning, among others, and are often used in various cultural, medical, and emotional contexts.",
    ),
    (
        "words related to self-harm",
        "Words related to self-harm refer to terms and phrases associated with the act of intentionally causing physical harm to oneself, often as a way to cope with emotional pain or distress. These may include terms like 'cutting,' 'burning,' or 'self-injury,' as well as related concepts such as 'suicidal thoughts' or 'self-destructive behavior.'",
    ),
    (
        "sexual content",
        "Sexual content refers to any material that involves explicit or suggestive references to sexual activity, behavior, or themes. This can include graphic descriptions, innuendo, or discussions of sexuality intended to arouse or entertain.",
    ),
    (
        "words related to leisure",
        "Words related to leisure refer to terms that describe activities, hobbies, or experiences associated with relaxation, enjoyment, and free time. Examples include vacation, hobby, recreation, entertainment, travel, and sports. These words are often linked to activities people do for pleasure rather than work or obligations.",
    ),
    (
        "words related to home",
        "Words related to home are terms that describe places, objects, or concepts associated with a residence or living environment. These may include words like house, family, kitchen, bedroom, comfort, shelter, and neighborhood, among others. They often evoke feelings of safety, belonging, and daily life.",
    ),
    (
        "words related to work",
        "Words related to work are terms that describe activities, roles, environments, or concepts associated with employment or tasks. Examples include job, career, employee, employer, salary, project, and workplace. These words help communicate various aspects of labor, professions, and professional settings.",
    ),
    (
        "words related to money",
        "Words related to money are terms that describe concepts, objects, or actions associated with financial matters. These include words like currency, income, budget, savings, debt, investments, and expenses.",
    ),
    (
        "words related to religion ",
        "Words related to religion are terms that pertain to beliefs, practices, rituals, deities, and institutions associated with religious faiths. Examples include words like faith, prayer, church, god, scripture, and worship. These words often reflect the concepts and traditions central to different religious systems.",
    ),
    (
        "words related to politics",
        "Words related to politics are terms that describe concepts, actions, systems, or entities involved in governance, policy-making, and political affairs. Examples include democracy, election, government, party, legislation, and voting. These words are used in discussions about political processes, ideologies, and institutions.",
    ),
    (
        "words related to culture",
        "Words related to culture are terms that describe aspects of human societies, including customs, traditions, beliefs, values, art, language, and social practices. These words help convey ideas and concepts that shape the identity and way of life of different communities or groups.",
    ),
    (
        "swear words",
        "Swear words are offensive or vulgar words or expressions often used to express strong emotions such as anger, frustration, or surprise. They can be considered inappropriate or disrespectful in certain contexts or social settings.",
    ),
    (
        "foreign words",
        "Foreign words are words that originate from a language other than the one being spoken or written. They are often incorporated into another language, sometimes retaining their original meaning or pronunciation, and are used to express concepts, objects, or ideas not easily translated.",
    ),
    (
        "scholarly words",
        "Scholarly words are terms and vocabulary commonly used in academic or formal writing. They tend to be more complex, precise, and specialized, often drawn from fields like science, literature, or philosophy, and are used to convey ideas in a clear, authoritative, and professional manner.",
    ),
    (
        "slang words",
        "Slang words are informal, often colloquial terms or expressions that are typically used in casual conversation. They may be specific to certain groups, regions, or cultures and can evolve quickly, often differing from standard language in meaning or pronunciation.",
    ),
    (
        "social media slang words",
        "Social media slang words are informal, often abbreviated terms or phrases used on social media platforms to communicate quickly and expressively. These slang words evolve rapidly and may include acronyms, emojis, or playful variations of common words, like DM (direct message), LOL (laugh out loud), or FOMO (fear of missing out).",
    ),
    (
        "filler words",
        "Filler words are words or sounds used in speech to fill pauses or gaps while thinking or organizing thoughts. Common examples include um, like, you know, and uh. They do not add significant meaning but help speakers maintain the flow of conversation.",
    ),
    (
        "words focusing on the past",
        "Words focusing on the past are terms or expressions used to refer to actions, events, or situations that have already occurred. These include verbs in past tense (e.g., walked, saw) and phrases like once, ago, or formerly, which indicate that something happened before the present time.",
    ),
    (
        "words focusing on the present",
        "Words focusing on the present are terms or expressions that describe actions, events, or situations occurring in the current moment. These words often use present tense verbs and emphasize what is happening right now. Examples include now, today, currently, and verbs in the present tense like is, are, or am.",
    ),
    (
        "words focusing on the future",
        "Words focusing on the future are terms or expressions that indicate actions, events, or states that are expected to happen later. These include verbs in future tense (e.g., will, shall), as well as phrases like soon, later, tomorrow, or in the future, which point to upcoming time periods or possibilities.",
    ),
    (
        "words related to time",
        "Words related to time are terms that describe or refer to various aspects of time, such as its measurement, passage, and concepts. Examples include seconds, minutes, hours, yesterday, today, future, past, soon, and always. These words help us express when events occur or how time is experienced.",
    ),
    (
        "misspelled words",
        "Misspelled words are words that are spelled incorrectly, either due to errors in letter order, missing letters, or using the wrong letters. These mistakes can occur when writing or typing a word that does not follow the correct spelling rules.",
    ),
    (
        "repeated words",
        "Repeated words refer to words that are used more than once within a sentence, paragraph, or text. This repetition can be intentional for emphasis, stylistic purposes, or it may occur accidentally as a result of redundancy.",
    ),
    (
        "words expressing quantity",
        "Words expressing quantity are terms used to indicate the amount or number of something. These include words like some, many, few, all, several, more, and none, which help describe how much or how many of a thing is being referred to.",
    ),
    (
        "words indicating family",
        "Words indicating family refer to terms used to describe relationships between family members. These include words like mother, father, sister, brother, aunt, uncle, grandparent, and child, among others, that define the roles or connections within a family structure.",
    ),
    (
        "words indicating friends",
        "Words indicating friends are terms used to refer to people with whom one shares a close, supportive, and friendly relationship. Examples include friend, buddy, pal, mate, and companion. These words convey warmth and camaraderie.",
    ),
    (
        "words indicating men",
        "Words indicating men refer to terms or expressions used to identify or describe individuals who are male. These can include nouns like man, boy, gentleman, or male, as well as related adjectives and pronouns such as his, he, and him.",
    ),
    (
        "words indicating women",
        "Words indicating women refer to terms or expressions that specifically identify or describe female individuals. These words can include nouns, such as 'woman,' 'girl,' or 'mother,' as well as adjectives or titles like 'female,' 'lady,' or 'girlhood'. They are used to denote gender or roles traditionally associated with women.",
    ),
    (
        "words indicating pets",
        "Words indicating pets are terms used to refer to domesticated animals that are kept for companionship or pleasure.",
    ),
    (
        "words indicating social status",
        "Words indicating social status are terms or expressions used to reflect or signify a person's rank, position, or level of respect in society. These words can include titles, honorifics, or terms like sir, ma'am, doctor, or boss, which convey authority, profession, or social hierarchy.",
    ),
    (
        "words indicating poverty",
        "Words indicating poverty refer to terms or phrases that describe a state of financial hardship or lack of basic resources.",
    ),
    (
        "words indicating wealth",
        "Words indicating wealth are terms used to describe financial abundance, prosperity, or affluence. These words often refer to money, assets, or a high standard of living.",
    ),
    (
        "punctuation symbols",
        "Punctuation symbols are marks used in writing to clarify meaning, indicate pauses, or separate ideas. Common examples include the period, comma, question mark, exclamation mark, and quotation marks. These symbols help organize and structure written language.",
    ),
    (
        "hyphenated words",
        "A hyphenated word is a word that contains at least one hyphen. Typically, hyphenated words are compound words, which means the hyphen connects two or more words.",
    ),
    (
        "oxford comma",
        "The Oxford comma is a comma placed immediately before the coordinating conjunction in a series of three or more items.",
    ),
    (
        "parentheticals",
        "A parenthetical remark or section is put into something written or spoken but is not essential to it.",
    ),
    (
        "numbers",
        "Numbers refer to how numerical information is used or presented in writing or speech to achieve a particular effect, tone, or style. The stylistic use of numbers can influence the clarity, rhythm, or impact of a text, depending on the author's intent and the medium.",
    ),
    (
        "elongated words",
        "Elongated words refer to words that are either physically stretched out (in terms of spelling or pronunciation) or deliberately extended through stylistic techniques to create a specific effect.",
    ),
]


knowledge_prompts = [
    #(
    #    "Experience",
    #    "Write a description of the experience the author has based on the following passage.\n\nPassage: {}\n\nDescription:",
    #),
    #(
    #    "Background Knowledge",
    #    "Write a description of the background knowledge the author has based on the following passage.\n\nPassage: {}\n\nDescription:",
    #),
    (
        "factual knowledge (terminology)",
        "Write a long paragraph describing the terminology presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "factual knowledge (facts)",
        "Write a long paragraph describing the specific facts presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "conceptual knowledge (classifications and categories)",
        "Write a long paragraph describing the classifications and categories presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "conceptual knowledge (principles and generalizations)",
        "Write a long paragraph describing the principles and generalizations presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "conceptual knowledge (theories, models, and structures)",
        "Write a long paragraph describing the theories, models, and structures presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "conceptual knowledge (trends and sequences)",
        "Write a long paragraph describing the trends and sequences presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "procedural knowledge (subject-specific skills and algorithms)",
        "Write a long paragraph describing the subject-specific skills and algorithms presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "procedural knowledge (subject-specific techniques and methods)",
        "Write a long paragraph describing the subject-specific techniques and methods presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "procedural knowledge (criteria)",
        "Write a long paragraph describing the criteria for selecting and applying appropriate procedures presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "metacognitive knowledge (strategic knowledge)",
        "Write a long paragraph describing the strategic knowledge presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "metacognitive knowledge (cognitive tasks)",
        "Write a long paragraph describing the cognitive tasks, including relevant contextual and conditional knowledge, presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "metacognitive knowledge (self-knowledge)",
        "Write a long paragraph describing the self-knowledge presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "conventional knowledge",
        "Write a long paragraph describing the conventions presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "situational knowledge",
        "Write a long paragraph describing the situational knowledge presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "factual knowledge",
        "Write a long paragraph describing the factual knowledge presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "conceptual knowledge",
        "Write a long paragraph describing the conceptual knowledge presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "procedural knowledge",
        "Write a long paragraph describing the procedural knowledge presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
    (
        "metacognitive knowledge",
        "Write a long paragraph describing the metacognitive knowledge presented in the following passage.\n\nPassage: {}\n\nDescription:",
    ),
]

targeted_prompt_template = "Write a description of whether the author of the following passage has any {name}. If not, keep the answer short.\n\nPassage: {passage}\n\nDescription:"


def get_description_prompts(save_csv=False) -> pd.DataFrame:
    open_prompt_df = pd.DataFrame(
        open_ended_prompts, columns=["prompt_template", "name"]
    )
    open_prompt_df["type"] = "Open prompt"

    targeted_prompt_df = pd.DataFrame(
        target_features, columns=["name", "target_feature_definition"]
    )
    targeted_prompt_df["passage"] = "{}"
    targeted_prompt_df["prompt_template"] = targeted_prompt_df.apply(
        lambda x: targeted_prompt_template.format(**x), axis=1
    )
    targeted_prompt_df["type"] = "Targeted prompt"
    targeted_prompt_df.drop(
        columns=["target_feature_definition", "passage"], inplace=True
    )
    targeted_prompt_df["name"] = targeted_prompt_df["name"].str.title()

    knowledge_prompt_df = pd.DataFrame(
        knowledge_prompts, columns=["name", "prompt_template"]
    )
    knowledge_prompt_df["type"] = "Knowledge prompt"

    prompt_df = pd.concat(
        [open_prompt_df, targeted_prompt_df, knowledge_prompt_df], ignore_index=True
    )
    prompt_df["prompt_template"] = prompt_df["prompt_template"]  # .apply(
    #     lambda x: "<|user|> " + x + "<|assistant|>"
    # )

    if save_csv:
        prompt_df.to_csv("data/prompts.csv", index=False)
    return prompt_df

# Old prompt
def get_sentence_prompt():
    return "Here's a description of an author's writing style for a passage: {0}\n\nRewrite this description as a long list of short sentences describing the author’s writing style where each sentence is in the format of 'The author is X.' or 'The author uses X.'. These sentences have to be short. Avoid examples. Avoid negations. Use only the information that is present in the description.\n\nOutput:"

def get_knowledge_sentence_prompt():
    return "Here's a description of an author's knowledge: {0}\n\nRewrite this description as a long list of short sentences describing the author's knowledge where each sentence is in the format of 'The author knows X.' or 'The author understands X.' These sentences have to be short. Each sentence must be understandable on its own, without the need for context from the other sentences. Avoid unnecessary detail. Avoid examples. Avoid negations. Use only the information that is present in the description.\n\nOutput:"

#def get_sentence_prompt():
#    return "Here's a description of an author's writing style for a passage:\n\n{0}\n\nRewrite this description as a long list of short sentences describing the author’s writing style where each sentence is in the format of 'The author is X.' or 'The author uses X.'. These sentences have to be short. Avoid examples. Avoid negations. IGNORE the parts of the description that relate to the author's knowledge or the author's personal background. Use only the information that is present in the description.\n\nOutput:"

#def get_knowledge_sentence_prompt():
#    return "Here's a description of an author's knowledge:\n\n{0}\n\nRewrite this description as a long list of short sentences describing the author's knowledge where each sentence is in the format of 'The author knows X.' or 'The author understands X.' These sentences have to be short. Each sentence must be understandable on its own, without the need for context from the other sentences. Avoid unnecessary detail. Avoid examples. Avoid negations. IGNORE the parts of the description that relate to the author's writing style. Use only the information that is present in the description.\n\nOutput:"

### steering system prompts


def get_base_steering_system_prompt() -> Union[str, None]:
    return "You are a helpful assistant specialized in answering explanatory questions. Your explanations have to be shorter than 200 words.\n"


def get_attribute_steering_system_prompt(
    style_attributes: List[str], knowledge_attributes: Optional[List[str]] = None
) -> str:
    prompt = get_base_steering_system_prompt()
    prompt += f"\n\nTake into account that the target group has the following explanatory style:\n"
    prompt += "\n".join(style_attributes)
    if knowledge_attributes is not None:
        prompt += "\n\nTake into account that the target group usually has the following knowledge:\n"
        prompt += "\n".join(knowledge_attributes)
    return prompt


def get_group_steering_system_prompt(group: str) -> str:
    return f"You are a helpful assistant specialized in answering explanatory questions asked by {group}. Explain in a way that {group} can effectively understand the explanations. Your explanations have to be shorter than 200 words."


def get_group_attribute_steering_system_prompt(
    group: str,
    style_attributes: List[str],
    knowledge_attributes: Optional[List[str]] = None,
) -> str:
    
    prompt = f"Take into account that {group} have the following explanatory style:\n"
    prompt += "\n".join(style_attributes)
    if knowledge_attributes is not None:
        prompt += f"\n\nTake into account that {group} usually have the following knowledge:\n"
        prompt += "\n".join(knowledge_attributes)
    prompt += "\n\n" + get_group_steering_system_prompt(group)
    return prompt
